﻿# Claude CLI 资源管理器右键菜单安装程序
# 仅写入 HKEY_CURRENT_USER，不需要管理员权限。

$ErrorActionPreference = 'Stop'

$menuTitle       = '用 Claude CLI 打开'
$continueTitle   = '用 Claude CLI 继续上次对话'
$keyPath         = 'HKCU:\Software\Classes\Directory\Background\shell\ClaudeCLI'
$continueKeyPath = 'HKCU:\Software\Classes\Directory\Background\shell\ClaudeCLIContinue'

function Find-ClaudeCli {
    $found = @()

    # 1. PATH 中的 claude
    $cmd = Get-Command claude -ErrorAction SilentlyContinue
    if ($cmd) { $found += $cmd.Source }

    # 2. 常见安装位置
    $found += @(
        (Join-Path $env:USERPROFILE '.local\bin\claude.exe'),
        (Join-Path $env:USERPROFILE '.local\bin\claude.cmd'),
        (Join-Path $env:APPDATA 'npm\claude.cmd'),
        (Join-Path $env:LOCALAPPDATA 'Programs\claude\claude.exe')
    )

    # 3. WinGet 安装目录
    $wingetRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
    if (Test-Path -LiteralPath $wingetRoot) {
        Get-ChildItem -LiteralPath $wingetRoot -Directory -Filter 'Anthropic.ClaudeCode_*' -ErrorAction SilentlyContinue |
            ForEach-Object {
                Get-ChildItem -LiteralPath $_.FullName -Filter 'claude.exe' -Recurse -File -ErrorAction SilentlyContinue |
                    ForEach-Object { $found += $_.FullName }
            }
    }

    foreach ($p in $found) {
        if ($p -and (Test-Path -LiteralPath $p -PathType Leaf)) { return $p }
    }
    return $null
}

Write-Host ''
Write-Host '=== Claude CLI 资源管理器右键菜单 安装程序 ===' -ForegroundColor Cyan
Write-Host ''

$claude = Find-ClaudeCli
if (-not $claude) {
    Write-Host '未检测到 Claude CLI，请先安装：' -ForegroundColor Red
    Write-Host ''
    Write-Host '  winget install Anthropic.ClaudeCode'
    Write-Host ''
    Write-Host '或使用 npm：'
    Write-Host ''
    Write-Host '  npm install -g @anthropic-ai/claude-code'
    Write-Host ''
    Write-Host '安装完成后，重新运行本安装程序。'
    exit 1
}

Write-Host ("Claude CLI 路径 : {0}" -f $claude)

$wt = Get-Command wt.exe -ErrorAction SilentlyContinue
if ($wt) {
    $command         = '"{0}" -d "%V\." cmd.exe /k "{1}"' -f $wt.Source, $claude
    $continueCommand = '"{0}" -d "%V\." cmd.exe /k "{1}" --continue' -f $wt.Source, $claude
    Write-Host '终端           : Windows Terminal'
} else {
    $command         = 'cmd.exe /k cd /d "%V\." && "{0}"' -f $claude
    $continueCommand = 'cmd.exe /k cd /d "%V\." && "{0}" --continue' -f $claude
    Write-Host '终端           : 命令提示符（未找到 Windows Terminal）'
}

function Install-MenuEntry([string]$key, [string]$title, [string]$cmd) {
    New-Item -Path $key -Force | Out-Null
    New-ItemProperty -Path $key -Name 'MUIVerb'  -Value $title -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $key -Name 'Position' -Value 'Top'   -PropertyType String -Force | Out-Null
    if ($claude -like '*.exe') {
        New-ItemProperty -Path $key -Name 'Icon' -Value $claude -PropertyType String -Force | Out-Null
    }
    New-Item -Path "$key\command" -Force | Out-Null
    Set-Item -Path "$key\command" -Value $cmd
}

Install-MenuEntry $keyPath         $menuTitle     $command
Install-MenuEntry $continueKeyPath $continueTitle $continueCommand

Write-Host ''
Write-Host '安装完成。' -ForegroundColor Green
Write-Host '用法：在任意文件夹空白处右键 -> “显示更多选项”（Windows 11），然后选择：'
Write-Host '  “用 Claude CLI 打开”           新对话'
Write-Host '  “用 Claude CLI 继续上次对话”   恢复该文件夹最近一次会话'
exit 0


