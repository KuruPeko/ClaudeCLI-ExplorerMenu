﻿# Claude CLI 资源管理器右键菜单卸载程序

$ErrorActionPreference = 'Stop'

$keyPaths = @(
    'HKCU:\Software\Classes\Directory\Background\shell\ClaudeCLI',
    'HKCU:\Software\Classes\Directory\Background\shell\ClaudeCLIContinue'
)

Write-Host ''
Write-Host '=== Claude CLI 资源管理器右键菜单 卸载程序 ===' -ForegroundColor Cyan
Write-Host ''

$removed = $false
foreach ($keyPath in $keyPaths) {
    if (Test-Path $keyPath) {
        Remove-Item -Path $keyPath -Recurse -Force
        $removed = $true
    }
}
if ($removed) {
    Write-Host '已移除 Claude CLI 右键菜单项。' -ForegroundColor Green
} else {
    Write-Host '没有找到已安装的菜单项，无需卸载。'
}

exit 0


